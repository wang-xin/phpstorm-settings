/**
${NAME}
${PARAM_DOC}
${THROWS_DOC}
#if (${TYPE_HINT} != "void") * @return ${TYPE_HINT}
#end
@author King
*/
